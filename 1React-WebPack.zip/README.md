# React-WebPack
A extremely basic WebPack/React starter kit. Comes with the bare necesseties required to run React with WebPack as the module loader.

# How to run
npm run dev
