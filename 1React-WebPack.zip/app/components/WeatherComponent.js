import React from 'react';
var styles = require('./../styles'); 

export default React.createClass({
    
    getInitialState () {
        return {
            forecast: 'Loading...',
            tempHi: 0,
            tempLo: 0 
        };
    },
    
    render () {
        return (
            <div>
            {this.props.day}
                <ul className={styles.tabPanels}>
                    <li>Forecast: {this.state.forecast}</li>    
                    <li>temp High: {this.state.tempHi}</li>
                    <li>Temp Low: {this.state.tempLo}</li>
                </ul>
            </div>
        );
    }
});
