var ReactDOM = require('react-dom');
var React = require('react');
var styles = require('./styles'); 

var data = require('./data'); 

import storage from './lib/storage';
import xml2json from './lib/xml2Json';
import fetchWeatherData from './api/fetchWeatherData';
import WeatherComponent from './components/WeatherComponent'; 


const NO_OF_DAYS = 28;


class App extends React.Component {
    
    constructor(props) {
    super(props);
    this.state = {
            forecast: 'Loading...',
            tempHi: 0,
            tempLo: 0 
    }
  }
    
// interface adapter 

    getToday (){
      return new Date().getDay();//js is 0 based index  
    }
    
    //When calling weather API , pass this nr plus 1
    getNextDay (date){
      var next = (date + 1) % 6;
      return next;
    }

  
  
//ReactDOM.render(<WeatherComponent name="{data.name}"/>, document.getElementById('app'));    
        
    render (){
        return (
            <div>
            <h1>Weather Forecast</h1>
                <WeatherComponent day={this.getToday()} />
                <WeatherComponent day={this.getNextDay(this.getToday())} />
            </div>
        )
    }
};

ReactDOM.render(<App data="{data.name}"/>, document.getElementById('app'));


var Historic = function(noOfDays){
        
    var self = this;
    var nDays = noOfDays;
    var hiAvg = 0;
    var loAvg = 0;
    
    for(var i=1; i<=nDays; i++){
        //debugger
        hiAvg += getHiRandom();
        loAvg += getLoRandom();
    }
    
    hiAvg = hiAvg / noOfDays;
    loAvg = loAvg /noOfDays;
    
    function getRandomInt(min, max) {
        var rand = Math.floor(Math.random() * (max - min + 1)) + min;
        console.log("Random int= " + rand);
        return rand;
    }
    
    function getHiRandom(){
        return getRandomInt(15, 25);
    };
    
    function getLoRandom(){
        return getRandomInt(5, 15);
    };

    self.getHiAvg = function(){
        return hiAvg;
    };
    
    self.getLoAvg = function(){
        return loAvg;
    };

};



var weatherPanel = function(date){
    
    var avgHi = historicalData.getHiAvg();
    var avgLo = historicalData.getLoAvg();
    var day = date + 1;
    
    getWSdata('http://wxdata.weather.com/wxdata/weather/local/UKXX0085?cc=*&unit=m&dayf=' + day)
    .then(function (value) {
        debugger
        var obj = JSON.parse(value);
        console.log(JSON.stringify(obj, null, 4));
        console.log('Contents: ' + value);
        
        storage.set(obj);
    }).catch(function (err) {
        console.error('Something went wrong', err);
    });
        
        
    var tempDiff = function(weatherAPITemp, avg) {
        return weatherAPITemp - avg;
    };
};

// interface adapter
var DateHandler = function(){
    
    var self = this;
    var today = new Date().getDay();
    var next = today;
    
    self.getToday = function(){
      return today;//js is 0 based index  
    } 
    
    //When calling weather API , pass this nr plus 1
    self.getNextDay = function(date){
        next = (day + 1) % 6;
      return next;
    }; 
};


var dateAdapter = new DateHandler();

var historicalData = new Historic(NO_OF_DAYS);

