import React from 'react';
import TestUtils from 'react-addons-test-utils';
import test from 'tape';

function shallowRenderTodo(todo) {
  const renderer = TestUtils.createRenderer();
  renderer.render(<WeatherComponent name={name} />);
  return renderer.getRenderOutput();
}


test('Weather component', (t) => {
  t.test('tests if weekdays map to 7 day slots', (t) => {
    const todo = { id: 1, name: 'Buy Milk', done: false };
    const result = shallowRenderTodo(todo);

    t.test('It renders the text of the todo', (t) => {
      var dateConverter = function(){
    
        var self = this;
        
        self.getToday = function(){
        return new Date().getDay();//js is 0 based index
        } 
        
        self.getNextDay = function(date){
        return ((date + 1) % 6) + 1;
        }; 
    };


      t.equal(result.props.children[0].props.children, 'Buy Milk');
    });
  });
});
