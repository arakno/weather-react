module.exports = [
  { name: 'Today', description: 'Lorem ipsum dolor sit amet' },
  { name: 'Tomorrow', description: 'Eiusmod tempor incidit.' },
  { name: 'Next Week', description: 'Sit amet, consectet.' },
];

