var React = require('react');

var styles = require('./styles'); 

export default React.createClass({
/*
 var hi = weatherPanel.tempDiff(weatherAPITemp, hiAvg);
 var lo = weatherPanel.tempDiff(weatherAPITemp, loAvg);    
 
 var strToPrint = function(value){
     if (value > 0) {
         return "+" + value;
     } else if (value < 0){
         return "-" + value;
     }
     
 }
  */  
    render () {
        return (
            <div>
            My weather app
                <ul className={styles.tabPanels}>
                    <li>Forecast: </li>    
                    <li>temp High: strToPrint</li>
                    <li>Temp Low: </li>
                </ul>
            </div>
        );
    }
});
