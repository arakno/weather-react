var ReactDOM = require('react-dom');
var React = require('react');
var styles = require('./styles'); 

import storage from './lib/storage';
import xml2json from './lib/xml2json';

import fetchWeatherData from './api/fetchWeatherData';
import WeatherComponent from './components/WeatherComponent'; 


const NO_OF_DAYS = 28;


class WeatherApp extends React.Component {
    
    constructor(props) {
    super(props);
    this.state = {
            forecast: 'Loading...',
            tempHi: 0,
            tempLo: 0
    }
  } 
  
    getToday (){
      var today = new Date().getDay();//js is 0 based index
      return today;  
    }
    
    getNextDay (date){
      var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
      var next = (date) % 7;
      return days[next];
    }    
        
    render (){
        return (
            <div>
            <h1>Weather Forecast</h1>
                <WeatherComponent day={this.getNextDay(this.getToday())} />
                <WeatherComponent day={this.getNextDay(this.getToday() +1)} />
                <WeatherComponent day={this.getNextDay(this.getToday() +2)} />
                <WeatherComponent day={this.getNextDay(this.getToday() +3)} />
            </div>
        )
    }
};

ReactDOM.render(<WeatherApp data="{data.name}"/>, document.getElementById('app'));

var App = {};
App.Historic = {};
(function(self){
        
    var nDays = NO_OF_DAYS;
    var hiAvg = 0;
    var loAvg = 0;
    
    function getRandomInt(min, max) {
        var rand = Math.floor(Math.random() * (max - min + 1)) + min;
        console.log("Random int= " + rand);
        return rand;
    }
    
    function getHiRandom(){
        return getRandomInt(15, 25);
    };
    
    function getLoRandom(){
        return getRandomInt(5, 15);
    };

    self.getHiAvg = function(){
        return hiAvg;
    };
    
    self.getLoAvg = function(){
        return loAvg;
    };
    
    self.init = function (noOfDays) {
        nDays = noOfDays;
        
        for(var i=1; i<=nDays; i++){
        //debugger
        hiAvg += getHiRandom();
        loAvg += getLoRandom();
        }
    
        hiAvg = hiAvg / noOfDays;
        loAvg = loAvg /noOfDays;
    }

})(App.Historic);


App.Panel = {}; 
(function(self){
    
    var result;
    
    self.init = function(date){
        var avgHi = App.Historic.getHiAvg();
        var avgLo = App.Historic.getLoAvg();
        var day = date + 1;
        
        storage.clear();
        
        //fetchWeatherData.getWSdata('http://wxdata.weather.com/wxdata/weather/local/UKXX0085?cc=*&unit=m&dayf=' + day)
        fetchWeatherData.getWSdata("http://stefangeorg.net/proxy.php?url=" + encodeURIComponent('http://wxdata.weather.com/wxdata/weather/local/UKXX0085?cc=*&unit=m&dayf=' + day))        
        .then(function (res) {
            
            var parser = new DOMParser();
            var xml = parser.parseFromString(res, 'text/xml');
            console.log(JSON.stringify(xml, null, 4));
            var json = xml2json.parse(xml);
            result = json;
            storage.set(json);
            
        }).catch(function (err) {
            console.error('Something went wrong', err);
        });
            
            
        self.tempDiff = function(weatherAPITemp, avg) {
            return weatherAPITemp - avg;
        }
    }
    
})(App.Panel);

// interface adapter
App.DateHandler = {}; 
(function(self){
    
    var today = new Date().getDay();
    var next = today;
    
    self.getToday = function(){
      return today;//js is 0 based index  
    }    
    //When calling weather API , pass this nr plus 1
    self.getNextDay = function(date){
        next = (date + 1) % 6;
      return next;
    }; 
})(App.DateHandler);



App.Historic.init(NO_OF_DAYS);
App.DateHandler.getNextDay(1);

App.Panel.init(2);